require 'robot_arm'
robot_arm:load_level('exercise 11')
robot_arm.speed =.95
for i=1, 10 do
  robot_arm:move_right()
  end
for i=1, 15 do
  robot_arm:grab()
if robot_arm:scan() == "white" then
  robot_arm:move_right()
end
  robot_arm:drop()
  robot_arm:move_left()
 end
if robot_arm:scan() == "white" then
  robot_arm:move_right()
end
