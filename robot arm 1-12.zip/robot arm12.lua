require 'robot_arm'
robot_arm:random_level(1)
robot_arm.speed = .9999999999

robot_arm:grab()
blok = robot_arm:scan()

while blok ~= nil do
  
  if robot_arm:scan() == "red" then
    for j=1, 9 do
      robot_arm:move_right()
    end
    robot_arm:drop()
    for  j=1, 9 do
      robot_arm:move_left()
    end
  end

  if robot_arm:scan() == "blue" then
    for j=1, 9 do
      robot_arm:move_right()
    end
    robot_arm:drop()
    for  j=1, 9 do
      robot_arm:move_left()
    end
  end

  if robot_arm:scan() == "green" then
    for j=1, 9 do
      robot_arm:move_right()
    end
    robot_arm:drop()
    for  j=1, 9 do
      robot_arm:move_left()
    end
  end

  if robot_arm:scan() == "white" then
    for j=1, 9 do
      robot_arm:move_right()
    end
    robot_arm:drop()
    for  j=1, 9 do
      robot_arm:move_left()
    end
  end

  robot_arm:grab()
  blok = robot_arm:scan()

end